# mypy: allow-untyped-defs
def test_spam(spam):
    assert spam == "spamspam"
