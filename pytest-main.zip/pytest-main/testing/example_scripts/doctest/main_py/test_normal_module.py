# mypy: allow-untyped-defs
def test_doc():
    """
    >>> 10 > 5
    True
    """
    assert False
