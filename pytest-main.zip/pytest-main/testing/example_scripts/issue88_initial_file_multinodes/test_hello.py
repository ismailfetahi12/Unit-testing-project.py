# mypy: allow-untyped-defs
def test_hello():
    pass
