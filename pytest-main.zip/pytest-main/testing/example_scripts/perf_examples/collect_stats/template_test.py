# mypy: allow-untyped-defs
def test_x():
    pass
