# mypy: allow-untyped-defs
def test():
    pass
