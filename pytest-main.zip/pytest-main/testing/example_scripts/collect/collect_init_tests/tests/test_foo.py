# mypy: allow-untyped-defs
def test_foo():
    pass
