# mypy: allow-untyped-defs
def test_init():
    pass
