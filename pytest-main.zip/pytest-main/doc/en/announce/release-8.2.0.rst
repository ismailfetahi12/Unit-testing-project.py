pytest-8.2.0
=======================================

The pytest team is proud to announce the 8.2.0 release!

This release contains new features, improvements, and bug fixes,
the full list of changes is available in the changelog:

    https://docs.pytest.org/en/stable/changelog.html

For complete documentation, please visit:

    https://docs.pytest.org/en/stable/

As usual, you can upgrade from PyPI via:

    pip install -U pytest

Thanks to all of the contributors to this release:

* Bruno Oliveira
* Daniel Miller
* Florian Bruhin
* HolyMagician03-UMich
* John Litborn
* Levon Saldamli
* Linghao Zhang
* Manuel López-Ibáñez
* Pierre Sassoulas
* Ran Benita
* Ronny Pfannschmidt
* Sebastian Meyer
* Shekhar verma
* Tamir Duberstein
* Tobias Stoeckmann
* dj
* jakkdl
* poulami-sau
* tserg


Happy testing,
The pytest Development Team
